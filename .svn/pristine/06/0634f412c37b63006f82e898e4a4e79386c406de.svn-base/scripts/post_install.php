<?php
function post_install() {

	if (strtolower($_POST['mode']) == 'install') {

        require_once('modules/Administration/Administration.php');

        $items = array();

        $items[0] = 'AOS_Quotes';
        $items[1] = 'AOS_Invoices';

        foreach($items as $item){

            $exists = file_exists('custom/modules/'.$item.'/metadata/editviewdefs.php');
            //check if 'modules/js/quotes.js exist, if so unset it and write back to file.
            if($exists) {
                require_once('custom/modules/'.$item.'/metadata/editviewdefs.php');

                foreach($viewdefs[$item]['EditView']['templateMeta']['includes'] as $num => $line){

                    if($line['file'] == 'modules/AOS_Quotes/js/Quote.js'){

                        unset($viewdefs[$item]['EditView']['templateMeta']['includes'][$num]);
                    }
                }
                ksort($viewdefs);
                write_array_to_file('viewdefs', $viewdefs, 'custom/modules/'.$item.'/metadata/editviewdefs.php');
            }
        }

    upgrade_aos();

	global $sugar_config;

	$sugar_config['aos']['version'] = '5.2.3';
	
	ksort($sugar_config);
	write_array_to_file('sugar_config', $sugar_config, 'config.php');

	?><br/>
	<h3>Advanced OpenSales by <a href="http://www.salesagility.com">SalesAgility</a></h3>
	<br/>
	German translation by Claudia Haring & Georg Schütz <a href="http://www.kamux.de">www.kamux.de</a><br/>
	Russian tranlsation by likhobory <a href="mailto:likhobory@mail.ru">likhobory@mail.ru</a><br/>
	Dutch translation by OpenSesame ICT <a href="http://www.osict.com">www.osict.com</a> <a href="mailto:bdm@osict.com">bdm@osict.com</a><br/>
	Finnish translation by Henri Vuolle <a href="mailto:henri.vuolle@kiwai.fi">henri.vuolle@kiwai.fi</a><br/>
	French translation by Patrick Lahaye <a href="http://www.axxone.fr">www.axxone.fr</a> <a href="mailto:patrick.lahaye@axxone.fr">patrick.lahaye@axxone.fr</a><br/>
	Italian translation by Andrea Motta<br/>
	Spanish translation by Morris X<br/>
	<br/><?php
		$modules = array('AOS_Contracts','AOS_Invoices','AOS_PDF_Templates','AOS_Products','AOS_Products_Quotes','AOS_Line_Item_Groups','AOS_Quotes');
		
		$actions = array('clearAll','rebuildAuditTables','rebuildExtensions','repairDatabase');

		require_once('modules/Administration/QuickRepairAndRebuild.php');
		$randc = new RepairAndClear();
		$randc->repairAndClearAll($actions, $modules, true,false);
		
		$_REQUEST['upgradeWizard'] = true;
		require_once('modules/ACL/install_actions.php');
		unset($_REQUEST['upgradeWizard']);

	}
		
}

function upgrade_aos(){
    global $sugar_config, $db;
    if(!isset($sugar_config['aos']['version']) || $sugar_config['aos']['version'] < 5.2){
        $db->query("UPDATE  aos_pdf_templates SET type = 'AOS_Quotes' WHERE type = 'Quotes'");
        $db->query("UPDATE  aos_pdf_templates SET type = 'AOS_Invoices' WHERE type = 'Invoices'");

        require_once('include/utils/file_utils.php');

        $old_files = array(
            'custom/Extension/modules/Accounts/Ext/Layoutdefs/Account.php',
            'custom/Extension/modules/Accounts/Ext/Vardefs/Account.php',
            'custom/Extension/modules/Contacts/Ext/Layoutdefs/Contact.php',
            'custom/Extension/modules/Contacts/Ext/Vardefs/Contact.php',
            'custom/Extension/modules/Opportunities/Ext/Layoutdefs/Opportunity.php',
            'custom/Extension/modules/Opportunities/Ext/Vardefs/Opportunity.php',
            'custom/Extension/modules/Project/Ext/Layoutdefs/Project.php',
            'custom/Extension/modules/Project/Ext/Vardefs/Project.php',
            'modules/AOS_Quotes/js/Quote.js',
        );

        foreach($old_files as $old_file){
            if( file_exists($old_file)){
                create_custom_directory('bak_aos/'.$old_file);
                sugar_rename($old_file, 'custom/bak_aos/'.$old_file);
            }
        }

    }
}
?>
