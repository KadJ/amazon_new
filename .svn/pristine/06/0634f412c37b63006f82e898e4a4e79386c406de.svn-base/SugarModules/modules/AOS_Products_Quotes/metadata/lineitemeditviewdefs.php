<?php
$viewdefs ['AOS_Products_Quotes'] = 
array (
  'LineItemEditView' => 
  array (
    'Lines' => 
    array (
      'Product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'product_qty',
            'label' => 'LBL_PRODUCT_QTY',
          ),
          1 => 
          array (
            'name' => 'product_qty',
            'label' => 'LBL_PRODUCT_QTY',
          ),
          2 => 
          array (
            'name' => 'product_list_price',
            'label' => 'LBL_PRODUCT_LIST_PRICE',
          ),
          3 => 
          array (
            'name' => 'product_discount',
            'label' => 'LBL_PRODUCT_DISCOUNT',
          ),
          4 => 
          array (
            'name' => 'product_unit_price',
            'label' => 'LBL_PRODUCT_UNIT_PRICE',
          ),
          5 => 
          array (
            'name' => 'vat_amt',
            'label' => 'LBL_VAT_AMT',
          ),
          6 => 
          array (
            'name' => 'product_total_price',
            'label' => 'LBL_PRODUCT_TOTAL_PRICE',
          ),
        ),
        1 => 
        array (
          0 => '',
          1 => 
          array (
            'name' => 'description',
            'label' => 'LBL_DESCRIPTION',
          ),
          2 => '',
          3 => 
          array (
            'name' => 'discount',
            'label' => 'LBL_DISCOUNT',
          ),
          4 => '',
          5 => 
          array (
            'name' => 'vat',
            'label' => 'LBL_VAT',
          ),
          6 => '',
        ),
      ),
    ),
  ),
);
?>
