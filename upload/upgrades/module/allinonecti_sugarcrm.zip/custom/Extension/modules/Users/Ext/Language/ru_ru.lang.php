<?php

$mod_strings['LBL_CTI_PANEL'] = 'Простые звонки - настройки';
$mod_strings['LBL_CTI_EXT'] = 'Внутренний номер';
$mod_strings['LBL_CTI_INBOUND'] = 'Показывать всплывающую карточку';
$mod_strings['LBL_CTI_OUTBOUND'] = 'Исходящий звонок кликом';
