<?php

$mod_strings['LBL_CTI_PANEL'] = 'All-In-One CTI integration settings';
$mod_strings['LBL_CTI_EXT'] = 'Extension';
$mod_strings['LBL_CTI_INBOUND'] = 'Incoming Call notification';
$mod_strings['LBL_CTI_OUTBOUND'] = 'Click-to-Call';
