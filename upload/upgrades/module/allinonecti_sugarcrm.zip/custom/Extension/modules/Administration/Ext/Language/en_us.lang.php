<?php
$mod_strings['LBL_CTI_TITLE'] = 'All-In-One CTI';
$mod_strings['LBL_CTI_DESC'] = 'All-In-One CTI - SugarCRM Integration';
$mod_strings['LBL_CTI'] = 'Сonnection parameters and other preferences';
$mod_strings['LBL_MANAGE_CTI'] = 'Configuration';
