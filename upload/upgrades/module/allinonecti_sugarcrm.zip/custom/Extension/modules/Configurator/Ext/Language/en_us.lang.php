<?php

$mod_strings['LBL_CTI_CONFIGURATION'] = 'All-In-One CTI';

$mod_strings['LBL_CTI_CLIENT_ID'] = 'Password';
$mod_strings['LBL_CTI_FORMAT'] = 'Match only last N digits';
$mod_strings['LBL_CTI_HOST'] = 'Host';
$mod_strings['LBL_CTI_PORT'] = 'Port';

$mod_strings['LBL_CTI_CLIENT_ID_DESC'] = '';
$mod_strings['LBL_CTI_FORMAT_DESC'] = '';
$mod_strings['LBL_CTI_HOST_DESC'] = '';
$mod_strings['LBL_CTI_PORT_DESC'] = '';
$mod_strings['LBL_PLEASE_WAIT'] = 'Please, wait. Connecting ...';
$mod_strings['LBL_CONNECTION_OPEN'] = 'Connection open';
$mod_strings['LBL_CONNECTION_CLOSE_CLEAN'] = 'Connection close';
$mod_strings['LBL_CONNECTION_CLOSE_NOCLEAN'] = 'Connection close with error';
$mod_strings['LBL_RECIEVED_MESSAGE'] = 'Revieved message';
$mod_strings['LBL_UNKNOWERROR'] = 'Unknow error';
$mod_strings['LBL_ERROR'] = 'Error';
$mod_strings['LBL_TEST_BUTTON_TITLE'] = 'Test connection';