<?php
$mod_strings['LBL_CTI_CONFIGURATION'] = 'Простые звонки';

$mod_strings['LBL_CTI_CLIENT_ID'] = 'Пароль';
$mod_strings['LBL_CTI_FORMAT'] = 'Учитывать последние n-цифр';
$mod_strings['LBL_CTI_HOST'] = 'Адрес сервера';
$mod_strings['LBL_CTI_PORT'] = 'Порт';

$mod_strings['LBL_CTI_CLIENT_ID_DESC'] = '';
$mod_strings['LBL_CTI_FORMAT_DESC'] = 'Учитывать последние n-цифр телефонного номера при поиске клиента в базе';

$mod_strings['LBL_CTI_CLIENT_ID_DESC'] = '';
$mod_strings['LBL_CTI_FORMAT_DESC'] = '';
$mod_strings['LBL_CTI_HOST_DESC'] = '';
$mod_strings['LBL_CTI_PORT_DESC'] = '';
$mod_strings['LBL_PLEASE_WAIT'] = 'Пожалуйста, подождите. Идет соединение ...';
$mod_strings['LBL_CONNECTION_OPEN'] = 'Соединение установлено';
$mod_strings['LBL_CONNECTION_CLOSE_CLEAN'] = 'Соединение закрыто';
$mod_strings['LBL_CONNECTION_CLOSE_NOCLEAN'] = 'Соединение закрыто с ошибкой';
$mod_strings['LBL_RECIEVED_MESSAGE'] = 'Получено сообщение';
$mod_strings['LBL_UNKNOWERROR'] = 'Неизвестная ошибка';
$mod_strings['LBL_ERROR'] = 'Ошибка';
$mod_strings['LBL_TEST_BUTTON_TITLE'] = 'Проверить соединение';