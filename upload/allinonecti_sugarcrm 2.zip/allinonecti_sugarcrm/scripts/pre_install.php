<?php if(!defined('sugarEntry'))define('sugarEntry', true);

function pre_install() {}
