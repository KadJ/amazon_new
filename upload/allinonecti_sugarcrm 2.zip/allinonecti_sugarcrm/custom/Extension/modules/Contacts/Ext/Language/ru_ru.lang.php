<?php

$mod_strings['LNK_NEW_RECORD'] = 'Создать нового контакта';
$mod_strings['LBL_PHONECALLS_SUBPANEL_TITLE'] = 'Телефонные звонки';
