<?php

$mod_strings['LNK_NEW_RECORD'] = 'Create new contact';
$mod_strings['LBL_PHONECALLS_SUBPANEL_TITLE'] = 'Phone calls';
