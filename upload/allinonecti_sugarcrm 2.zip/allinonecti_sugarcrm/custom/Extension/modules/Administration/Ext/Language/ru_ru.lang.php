<?php
$mod_strings['LBL_CTI_TITLE'] = 'Простые звонки';
$mod_strings['LBL_CTI_DESC'] = 'Интеграция с Простыми звонками';
$mod_strings['LBL_CTI'] = 'Подключение и настройка Простых звонков';
$mod_strings['LBL_MANAGE_CTI'] = 'Параметры';
